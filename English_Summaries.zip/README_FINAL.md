# Machine Learning & Deep Learning Course Summaries
# 머신러닝 및 딥러닝 강의 요약본

## 📊 Summary Statistics

- **Total Lectures**: 20
- **Languages**: Korean (KO) & English (EN)
- **Total Files**: 42 summary files (20 KO + 20 EN + 2 index files)

---

## 📁 File Organization

### Korean Summaries (한글 요약본)
- `Lecture01_Summary.md` through `Lecture20_Summary.md`
- Index: `LECTURES_INDEX.md`

### English Summaries (영어 요약본)
- `Lecture01_Summary_EN.md` through `Lecture20_Summary_EN.md`
- Index: `LECTURES_INDEX_EN.md`

---

## 🎯 Quick Access

### 📖 Start Here
- **Korean Readers**: [LECTURES_INDEX.md](LECTURES_INDEX.md)
- **English Readers**: [LECTURES_INDEX_EN.md](LECTURES_INDEX_EN.md)

### 📚 Course Structure

**Part 1: Foundations (Lectures 1-2)**
- Computer Structure & Networks
- Data Visualization

**Part 2: Mathematical Foundations (Lectures 3-5)**
- Set Theory to Linear Regression
- Linear to Logistic Regression
- Logistic Regression to MLP

**Part 3: Evaluation & Advanced Techniques (Lectures 6-9)**
- Supervised Learning Evaluation
- Deep Learning Fundamentals
- Loss, Optimization & Scheduling
- Initialization & Normalization

**Part 4-5: Data & Sequences (Lectures 10-12)**
- Data Modality & Feature Extraction
- Sequence Models
- Advanced Sequence Models

**Part 6: Transformers (Lectures 13-14)**
- Transformer Architecture
- Pre-trained Models & LLM Era

**Part 7: Generative Models (Lectures 15-16)**
- GANs
- Diffusion Models

**Part 8: Unsupervised Learning (Lectures 17-18)**
- Clustering Fundamentals
- Advanced Unsupervised Learning

**Part 9: Explainability (Lectures 19-20)**
- XAI Fundamentals
- SHAP & Deep Learning XAI

---

## 💡 What's Included in Each Summary

✅ **Overview**: What the lecture covers  
✅ **Learning Objectives**: What you will learn  
✅ **Key Topics**: Core subjects covered  
✅ **Key Concepts**: Important takeaways  
✅ **Prerequisites**: Required background  
✅ **Additional Resources**: Where to learn more

❌ **Not Included**: Detailed explanations, code examples, practice exercises (see original files)

---

## 🎓 Recommended Learning Paths

### Path 1: Complete Beginner
1. Start with Lectures 1-2 (Infrastructure)
2. Progress to Lectures 3-5 (Math & Basic Models)
3. Study Lecture 6 (Evaluation)
4. Continue sequentially

### Path 2: Focus on Deep Learning
1. Review Lectures 3-5 (Foundations)
2. Study Lectures 7-9 (Advanced Training)
3. Explore Lectures 13-14 (Transformers)
4. Add Lectures 15-16 (Generative Models)

### Path 3: Focus on Applications
1. Start with Lectures 1-2 (Infrastructure)
2. Learn Lectures 6, 10-12 (Evaluation & Sequences)
3. Study Lectures 13-14 (Transformers & LLMs)
4. Finish with Lectures 19-20 (Explainability)

---

## 📞 Instructor Contact

**Name**: Ho-min Park  
**Email**: homin.park@ghent.ac.kr | powersimmani@gmail.com  
**Institution**: Ghent University

---

## 📝 Notes

- Each summary is approximately 2 pages
- Summaries extract core concepts from comprehensive original lectures
- For full details, code, and exercises, refer to original lecture materials
- Original lectures are HTML-based interactive slides

---

## 🌟 Features

- **Bilingual**: Full Korean and English versions
- **Concise**: Focus on core concepts only
- **Structured**: Consistent format across all lectures
- **Searchable**: Easy to find specific topics
- **Progressive**: Builds from basics to advanced

---

**Version**: 1.0  
**Created**: November 2024  
**Format**: Markdown (.md)

---

For questions, corrections, or suggestions, please contact the instructor.
